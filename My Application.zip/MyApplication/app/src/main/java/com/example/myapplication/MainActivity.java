package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {

    private Button btn_exit, btn_clear;



    private static final String[] LABELS = new String[]{

            " ABORT 002 " ,
            " CLOSET 041",
            " AC 003",
            " CODE 042 " ,
            " ACCESS 004 " ,
            " COMMUNICATIONS 043 " ,
            " ALARM 005 " ,
            " COMPUTER 044" ,
            " AND 006 " ,
            " CONTROL 045 " ,
            " ANNOUNCEMENT 007 " ,
            " COOL 046 " ,
            " AREA 008 " ,
            " CRAWL 047 " ,
            " ARM 009 " ,
            " CURRENT 048 " ,
            " ARMED 010 " ,
            " DAY 049 " ,
            " ARMING 011 " ,
            " DEGREES 050 " ,
            " AT 012 " ,
            " DEN 051 " ,
            " ATTIC 013 " ,
            " DETECTOR 052 " ,
            " AUDIO 014 " ,
            " DIM 053 " ,
            " AUTO 015 " ,
            " DINING 054 " ,
            " AUTOMATION 016 " ,
            " DISARM 055 " ,
            " AUXILIARY 017 " ,
            " DISARMED 056 " ,
            " AWAY 018 " ,
            " DOCK 057 " ,
            " BABY’S 019 " ,
            " DOOR 058 " ,
            " BACK 020 " ,
            " DOWNSTAIRS 059 " ,
            " BASEMENT 021 " ,
            " DRIVEWAY 060 " ,
            " BATHROOM 022 " ,
            " EAST 061 " ,
            " BATTERY 023 " ,
            " EIGHT 062 " ,
            " BEDROOM 024 " ,
            " EIGHTEEN 063 " ,
            " BONUS 025 " ,
            " EIGHTY 064 “ , ",
            " BREAK 026 " ,
            " ELECTRIC 065 ",
            " BUTTON 027 " ,
            " ELEVEN 066 " ,
            " BYPASS 028 " ,
            " EMERGENCY 067 " ,
            " BYPASSED 029 " ,
            " ENTER 068 " ,
            " CABINET 030 " ,
            " ENTRANCE 069 " ,
            " CANCEL 031 " ,
            " ENTRY 070 " ,
            " CARBON MONOXIDE 032 " ,
            " ERROR 071 " ,
            " CELLAR 033 " ,
            " EXERCISE 072 ",
            " CELLULAR 034 " ,
            " EXIT 073 " ,
            " CELL RADIO 035 " ,
            " EXIT NOW 074 " ,
            " CENTER 036 " ,
            " EXTERIOR 075 " ,
            " CHECK 037 " ,
            " EXTERNAL 076 " ,
            " CHEST 038 " ,
            " FAILURE 077 " ,
            " CHILDREN’S 039 " ,
            " FAMILY 078 " ,
            " CHIME 040 " ,
            " FAN 079 " ,
            " FIFTEEN 080 " ,
            " INTRUSION 119 ",
            " FIFTY 081 " ,
            " IS 120 " ,
            " FIRE 082 " ,
            " KEY 121 " ,
            " FIRE ALERT 083 " ,
            " KEYFOB 122 " ,
            " FIRE DETECTOR 084 " ,
            " KEYPAD 123 " ,
            " FIRST 085 " ,
            " KIDS 124 " ,
            " FIVE 086 " ,
            " KITCHEN 125 " ,
            " FLOOD 087 " ,
            " LAUNDRY 126 " ,
            " FLOOR 088 ",
            " LEFT 127 " ,
            " FLUID 089 " ,
            " LEVEL 128 " ,
            " FOIL 090 " ,
            " LIBRARY 129 " ,
            " FOR 091 " ,
            " LIGHT 130 " ,
            " FORTY 092 " ,
            " LIGHTS 131 " ,
            " FOUR 093 " ,
            " LIQUOR 132 " ,
            " FOURTEEN 094 " ,
            " LIVING 133 " ,
            " FOURTH 095 " ,
            " LOADING 134 " ,
            " FREEZE 096 " ,
            " LOCK 135 " ,
            " FREEZER 097 " ,
            " LOFT 136 " ,
            " FRONT 098 " ,
            " LOW 137 " ,
            " FURNACE 099 " ,
            " MAIN 138 " ,
            " GAME 100 " ,
            " MAINTENANCE 139 " ,
            " GARAGE 101 " ,
            " MASTER 140 " ,
            " GAS 102 " ,
            " MEDICAL 141 " ,
            " GLASS 103 " ,
            " MEDICINE 142 " ,
            " GLASS BREAK 104 " ,
            " MENU 143 " ,
            " GUEST 105 " ,
            " MIDDLE 144 " ,
            " GUN 106 " ,
            " MONITOR 145 " ,
            " HALL 107 ",
            " MOTION 146 " ,
            " HALLWAY 108 " ,
            " MOTION DETECTOR 147 " ,
            " HANGING 109 " ,
            " MUD 148 " ,
            " HANGUP 110 " ,
            " NINE 149 " ,
            " HEAT 111 " ,
            " NINETEEN 150 " ,
            " HIGH 112 " ,
            " NINETY 151 " ,
            " HOME 113 " ,
            " NORTH 152 " ,
            " HOUSE 114 " ,
            " NOT 153 " ,
            " ICE 115 " ,
            " NOT READY 154 " ,
            " INSIDE 116 " ,
            " NO DELAY 155 ",
            " INSTANT 117 " ,
            " NO ENTRY DELAY 156 " ,
            " INTERIOR 118 " ,
            " NURSERY 157 " ,
            " OFF 158 " ,
            " SEVENTY 197 " ,
            " OFFICE 159 " ,
            " SHED 198 " ,
            " ON 160 " ,
            " SHOP 199 " ,
            " ONE 161 " ,
            " SIDE 200 " ,
            " ONE HUNDRED 162 " ,
            " SILENT 201 " ,
            " OUTPUT 163 " ,
            " SIREN 202 " ,
            " OUTSIDE 164 " ,
            " SIX 203 " ,
            " PANEL 165 " ,
            " SIXTEEN 204 " ,
            " PANIC 166 " ,
            " SIXTY 205 " ,
            " PANTRY 167 " ,
            " SKYLIGHT 206 " ,
            " PATIO 168 " ,
            " SLIDING 207 " ,
            " PERIMETER 169 " ,
            " SMOKE 208 " ,
            " PHONE LINE 170 " ,
            " SOUNDER 209 " ,
            " PLAY 171 " ,
            " SOUTH 210 " ,
            " POLICE 172 " ,
            " SPARE 212 " ,
            " POOL 173 " ,
            " STAIRS 213 " ,
            " POUND 174 " ,
            " STAR 214 " ,
            " POWER 175 " ,
            " STATUS 215 " ,
            " PRESS 176 " ,
            " STAY 216 " ,
            " PREVIOUS 177 " ,
            " STOP 217 " ,
            " PUMP 178 " ,
            " STORAGE 218 " ,
            " RADIO 179 " ,
            " STUDY 219 " ,
            " READY 180 " ,
            " SUMP 220 " ,
            " REAR 181 " ,
            " SUPERVISION 221 " ,
            " RELAY 182 " ,
            " SYSTEM 222 " ,
            " REMOTE 183 " ,
            " TAMPER 223 " ,
            " REPEAT 184 " ,
            " TEMPERATURE 224 " ,
            " RF JAM 185 " ,
            " TEN 225 " ,
            " RIGHT 186 " ,
            " TERMINATED 226 " ,
            " ROOM 187 " ,
            " THERMOSTAT 227 " ,
            " SAFE 188 " ,
            " THIRD 228 " ,
            " SECOND 189 " ,
            " THIRTEEN 229 " ,
            " SECURITY 190 " ,
            " THIRTY 230 " ,
            " SENSOR 191 " ,
            " THREE 231 " ,
            " SENSORS 192 " ,
            " TO 232 " ,
            " SESSION 193 " ,
            " TOOL 233 " ,
            " SET 194 " ,
            " TRANSMITTED 234 " ,
            " SEVEN 195 " ,
            " TRANSMITTER 235 " ,
            " SEVENTEEN 196 " ,
            " TROUBLE 236 " ,
            " TURN 237 " ,
            " DAUGHTER’S 276 " ,
            " TWELVE 238 " ,
            " DOORBELL 277 " ,
            " TWENTY 239 " ,
            " GIRL’S 278 " ,
            " TWO 240 " ,
            " IMAGE 279 " ,
            " UNLOCK 241 " ,
            " IMAGE SENSOR 280 " ,
            " UPPER 242 " ,
            " MAIN 281 " ,
            " UPSTAIRS 243 " ,
            " SON’S 282 " ,
            " USER 244 " ,
            " SUN 283 " ,
            " UTILITY 245 " ,
            " THEATER 284 " ,
            " VALVE 246 " ,
            " WING 285 " ,
            " VOICE 247 " ,
            " SWITCH 286 " ,
            " WALL 248 " ,
            " WATER 249 " ,
            " WEST 250 " ,
            " WINDOW 251 " ,
            " WIRELESS 252 " ,
            " YARD 253 " ,
            " ZERO 254 " ,
            " ZONE 255 " ,
            " BALCONY 256 " ,
            " COURTYARD 257 " ,
            " DECK 258 " ,
            " DETACHED 259 " ,
            " OVERHEAD 260 " ,
            " REFRIGERATOR 261 " ,
            " SERVICE 262 " ,
            " WAREHOUSE 263 " ,
            " GATE 264 " ,
            " APARTMENT 265 " ,
            " FOYER 266 " ,
            " TV 267 " ,
            " VIDEO 268 " ,
            " PORCH 269 " ,
            " CORNER 270 " ,
            " BELL 271 " ,
            " BOY’S 272 " ,
            " CAMERA 273 " ,
            " CAVE 274 " ,
            " DAUGHTERS 275"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState){


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_clear = findViewById(R.id.btn_clear);


        final AutoCompleteTextView[] actv = {findViewById(R.id.actv)};
        AutoCompleteTextView actv1 = findViewById(R.id.actv1);
        AutoCompleteTextView actv2 = findViewById(R.id.actv2);
        AutoCompleteTextView actv3 = findViewById(R.id.actv3);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, LABELS);
        actv[0].setAdapter(adapter);
        actv1.setAdapter(adapter);
        actv2.setAdapter(adapter);
        actv3.setAdapter(adapter);



       btn_exit = (Button)findViewById(R.id.btn_exit);
       btn_exit.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               moveTaskToBack(true);
               android.os.Process.killProcess(android.os.Process.myPid());
               System.exit(1);


           }
       });

               btn_clear.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View view) {
                       String getText = actv[0].getText().toString();
                       actv[0].getText().clear();
                       actv1.getText().clear();
                       actv2.getText().clear();
                       actv3.getText().clear();





                   }

               });





    }
}